<?php
    function Sum2(int $a, $b) {
		$b = $a + $b;
        return $b;
	} 
