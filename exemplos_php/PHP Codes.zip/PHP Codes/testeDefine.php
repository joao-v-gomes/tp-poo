<?php   
      define("x", 1);
      echo x;