<?php
    $a = 1;
    $b = 2;

	if ($a > $b) {
		echo "a is bigger than b\n";
	} elseif ($a == $b) {
		echo "a is equal to b\n";
	} else {
		echo "a is smaller than b\n";
	}
?>