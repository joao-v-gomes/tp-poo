<?php
    $f = "Hello World!";
    echo($f);
    echo("\n");
    print_r($f);

    echo("\n\n");
    $pi = 3.1415;
    $inteiro = 10;
    //$pi = 3;
    $inteiro = 3.5;

    echo "\npi = " ;
    var_dump( $pi);

    echo "\ninteiro = " . var_dump($inteiro);

    $a = "1";
    echo $a + 2;
