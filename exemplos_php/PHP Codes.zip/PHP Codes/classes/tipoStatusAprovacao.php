<?php
    enum TipoStatusAprovacao
    {
        case NA;
        case OK; 
        case NOK;               
    }
?>