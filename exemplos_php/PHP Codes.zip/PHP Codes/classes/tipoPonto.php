<?php
    enum TipoPonto
    {
        case INICIO;
        case FIM;        
    }
   
?>